Team 20 documentation!
================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   setup.md