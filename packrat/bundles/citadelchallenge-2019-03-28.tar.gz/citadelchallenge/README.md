# Citadel Datathon 2019 Team United Kingdom

Team: Harrison Zhu (Imperial), Taketomo Isazawa (Cambridge), Benjamin Hillyard (Oxford), Parley Yang (Oxford)

[![Documentation Status](https://readthedocs.org/projects/uk-citadel-team/badge/?version=latest)](https://uk-citadel-team.readthedocs.io/en/latest/?badge=latest)


Minimal requirements:

```
pipenv
pyenv
python==3.6
```


To setup locally for development:
```
pipenv install --dev
```

